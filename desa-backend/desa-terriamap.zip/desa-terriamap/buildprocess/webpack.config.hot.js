module.exports = require("./webpack.config")(true, true);
